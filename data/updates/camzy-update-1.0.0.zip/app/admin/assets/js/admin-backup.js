/* Backup & update management (admin-only) */
(function () {
  'use strict';

  function adminToken() {
    try {
      var s = JSON.parse(localStorage.getItem('as_admin_session') || 'null');
      return (s && s.token) || '';
    } catch (e) { return ''; }
  }
  function headers(json) {
    var h = {};
    try { var t = adminToken(); if (t) h.Authorization = 'Bearer ' + t; } catch (_) {}
    if (json) h['Content-Type'] = 'application/json';
    return h;
  }
  function fmtBytes(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / (1024 * 1024)).toFixed(2) + ' MB';
  }
  function msg(text, type) {
    var el = document.getElementById('bu-message');
    if (el) { el.textContent = text || ''; el.style.color = type === 'danger' ? '#B91C22' : (type === 'success' ? '#15803D' : 'var(--text-muted)'); }
    try { if (window.CamzyAdmin && window.CamzyAdmin.showToast) window.CamzyAdmin.showToast(text, type || 'info'); } catch (_) {}
  }

  var latestBackup = null;
  var backups = [];
  var packages = [];
  var selectedPackage = null;
  var ghRelease = null;
  var ghDownloadedFile = null;

  function renderStatus(data) {
    if (!data) return;
    var v = document.getElementById('bu-version');
    if (v) v.value = (data.version || (data.update && data.update.currentVersion) || '—');
    latestBackup = data.latestBackup || null;
    backups = Array.isArray(data.backups) ? data.backups : [];
    var ld = document.getElementById('bu-latest-date');
    if (ld) ld.value = latestBackup && latestBackup.createdAt ? new Date(latestBackup.createdAt).toLocaleString('fa-IR') : '—';
    var st = document.getElementById('bu-status');
    if (st) st.value = latestBackup ? (latestBackup.status || '—') : '—';
    var up = document.getElementById('bu-update');
    if (up) {
      var u = data.update || {};
      up.value = u.available ? ('بله — ' + (u.latestVersion || u.package || '')) : 'خیر';
    }
    renderBackups();
  }

  function renderBackups() {
    var tbody = document.querySelector('#bu-backups-table tbody');
    if (!tbody) return;
    if (!backups.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-muted)">پشتیبانی یافت نشد.</td></tr>';
      return;
    }
    tbody.innerHTML = backups.map(function (b) {
      return '<tr>' +
        '<td style="direction:ltr;text-align:left;font-size:12px">' + (b.filename || '') + '</td>' +
        '<td style="font-size:12px">' + (b.createdAt ? new Date(b.createdAt).toLocaleString('fa-IR') : '—') + '</td>' +
        '<td>' + fmtBytes(b.size) + '</td>' +
        '<td>' + (b.status || '—') + '</td>' +
        '<td><button type="button" class="btn btn-sm" data-bu-download="' + (b.filename || '') + '">دانلود</button></td>' +
        '</tr>';
    }).join('');
  }

  function setSelectedPackage(filename) {
    selectedPackage = filename || null;
    var info = document.getElementById('bu-selected-info');
    var pkg = packages.find(function (p) { return p.filename === selectedPackage; });
    if (info) {
      if (!pkg) info.textContent = 'بسته انتخاب‌شده: —';
      else info.textContent = 'بسته انتخاب‌شده: ' + pkg.filename + ' — نسخه: ' + (pkg.version || '—') + (pkg.notes ? (' — ' + pkg.notes) : '');
    }
  }

  function renderPackages() {
    var tbody = document.querySelector('#bu-packages-table tbody');
    if (!tbody) return;
    if (!packages.length) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:20px;color:var(--text-muted)">بسته‌ای یافت نشد.</td></tr>';
      return;
    }
    tbody.innerHTML = packages.map(function (p) {
      var checked = selectedPackage === p.filename ? ' checked' : '';
      return '<tr>' +
        '<td><input type="radio" name="bu-package" value="' + p.filename + '"' + checked + '></td>' +
        '<td style="direction:ltr;text-align:left;font-size:12px">' + p.filename + '</td>' +
        '<td>' + (p.version || '—') + '</td>' +
        '<td style="font-size:12px">' + (p.notes || '—') + '</td>' +
        '<td>' + fmtBytes(p.size) + '</td>' +
        '<td style="font-size:12px">' + (p.createdAt ? new Date(p.createdAt).toLocaleString('fa-IR') : '—') + '</td>' +
        '<td><button type="button" class="btn btn-sm btn-danger" data-bu-delete="' + p.filename + '">حذف</button></td>' +
        '</tr>';
    }).join('');

    if (!selectedPackage && packages.length) setSelectedPackage(packages[0].filename);
    else setSelectedPackage(selectedPackage);
  }

  function loadPackages() {
    fetch('/api/admin/updates', { headers: headers() })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        packages = Array.isArray(res.body.packages) ? res.body.packages : [];
        renderPackages();
      })
      .catch(function (e) { msg('خطا در بارگذاری بسته‌ها: ' + (e.message || e), 'danger'); });
  }

  function uploadPackage() {
    var input = document.getElementById('bu-upload-file');
    var btn = document.getElementById('bu-upload-btn');
    if (!input || !input.files || !input.files.length) { msg('یک فایل ZIP انتخاب کنید', 'danger'); return; }
    var file = input.files[0];
    var fd = new FormData();
    fd.append('file', file);
    var uploadMsg = document.getElementById('bu-upload-msg');
    if (uploadMsg) uploadMsg.textContent = 'در حال آپلود…';
    if (btn) btn.disabled = true;
    fetch('/api/admin/updates/upload', { method: 'POST', headers: { Authorization: (function(){ var t=adminToken(); return t ? 'Bearer '+t : ''; })() }, body: fd })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        if (uploadMsg) uploadMsg.textContent = 'آپلود با موفقیت انجام شد';
        if (input) input.value = '';
        if (res.body.filename) setSelectedPackage(res.body.filename);
        loadPackages();
        loadStatus();
      })
      .catch(function (e) { if (uploadMsg) uploadMsg.textContent = 'خطا در آپلود: ' + (e.message || e); })
      .finally(function () { if (btn) btn.disabled = false; });
  }

  function deletePackage(filename) {
    if (!filename) return;
    if (!confirm('بسته «' + filename + '» حذف شود؟')) return;
    fetch('/api/admin/updates/' + encodeURIComponent(filename), { method: 'DELETE', headers: headers() })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        if (selectedPackage === filename) selectedPackage = null;
        loadPackages();
        msg('بسته حذف شد', 'success');
      })
      .catch(function (e) { msg('خطا در حذف بسته: ' + (e.message || e), 'danger'); });
  }

  function loadStatus() {
    loadGitHubConfig();
    fetch('/api/admin/backup/status', { headers: headers() })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        renderStatus(res.body);
        loadPackages();
      })
      .catch(function (e) { msg('خطا در بارگذاری وضعیت: ' + (e.message || e), 'danger'); });
  }

  function createBackup() {
    var btn = document.getElementById('bu-create');
    if (btn) btn.disabled = true;
    msg('در حال ایجاد نسخه پشتیبان…', 'info');
    fetch('/api/admin/backup/create', { method: 'POST', headers: headers(true), body: '{}' })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        msg('نسخه پشتیبان با موفقیت ایجاد شد', 'success');
        loadStatus();
      })
      .catch(function (e) { msg('خطا در ایجاد پشتیبان: ' + (e.message || e), 'danger'); })
      .finally(function () { if (btn) btn.disabled = false; });
  }

  function downloadBackup(filename) {
    filename = filename || (latestBackup && latestBackup.filename);
    if (!filename) { msg('پشتیبانی برای دانلود وجود ندارد', 'danger'); return; }
    var url = '/api/admin/backup/download?file=' + encodeURIComponent(filename);
    fetch(url, { headers: headers() })
      .then(function (r) {
        if (!r.ok) throw new Error('download failed');
        return r.blob();
      })
      .then(function (blob) {
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
        msg('دانلود آغاز شد', 'success');
      })
      .catch(function () { msg('خطا در دانلود پشتیبان', 'danger'); });
  }

  function ghMsg(text, type) {
    var el = document.getElementById('bu-gh-config-msg');
    if (el) { el.textContent = text || ''; el.style.color = type === 'danger' ? '#B91C22' : (type === 'success' ? '#15803D' : 'var(--text-muted)'); }
  }
  function ghReleaseMsg(text, type) {
    var el = document.getElementById('bu-gh-release-msg');
    if (el) { el.textContent = text || ''; el.style.color = type === 'danger' ? '#B91C22' : (type === 'success' ? '#15803D' : 'var(--text-muted)'); }
  }

  function loadGitHubConfig() {
    fetch('/api/admin/updates/github/config', { headers: headers() })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        var b = res.body || {};
        var o = document.getElementById('bu-gh-owner');
        var r = document.getElementById('bu-gh-repo');
        if (o && b.owner) o.value = b.owner;
        if (r && b.repo) r.value = b.repo;
        var ts = document.getElementById('bu-gh-token-status');
        if (ts) ts.textContent = b.tokenConfigured ? 'پیکربندی شده (سرور)' : 'پیکربندی نشده (مخزن عمومی)';
      })
      .catch(function (e) { ghMsg('خطا در بارگذاری پیکربندی: ' + (e.message || e), 'danger'); });
  }

  function saveGitHubConfig() {
    var owner = (document.getElementById('bu-gh-owner') || {}).value || '';
    var repo = (document.getElementById('bu-gh-repo') || {}).value || '';
    owner = String(owner).trim();
    repo = String(repo).trim();
    if (!owner || !repo) { ghMsg('Owner و Repository الزامی هستند', 'danger'); return; }
    fetch('/api/admin/updates/github/config', { method: 'PUT', headers: headers(true), body: JSON.stringify({ owner: owner, repo: repo }) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        ghMsg('پیکربندی ذخیره شد', 'success');
        loadGitHubConfig();
      })
      .catch(function (e) { ghMsg('خطا در ذخیره: ' + (e.message || e), 'danger'); });
  }

  function renderGitHubRelease() {
    var card = document.getElementById('bu-gh-release-card');
    if (!card) return;
    if (!ghRelease) { card.style.display = 'none'; return; }
    card.style.display = '';
    var rel = ghRelease.release || {};
    var v = document.getElementById('bu-gh-version'); if (v) v.value = rel.version || '—';
    var p = document.getElementById('bu-gh-published'); if (p) p.value = rel.publishedAt ? new Date(rel.publishedAt).toLocaleString('fa-IR') : '—';
    var asset = ghRelease.asset;
    var a = document.getElementById('bu-gh-asset'); if (a) a.value = asset ? asset.name : '—';
    var s = document.getElementById('bu-gh-size'); if (s) s.value = asset ? fmtBytes(asset.size) : '—';
    var n = document.getElementById('bu-gh-notes'); if (n) n.value = rel.body || '';
    var d = document.getElementById('bu-gh-digest');
    if (d) {
      if (asset && asset.digest) d.textContent = 'SHA-256 انتشاریافته (' + (asset.digestSource || 'release') + '): ' + asset.digest;
      else if (asset && asset.sha256Asset) d.textContent = 'فایل جانبی SHA-256 در Release موجود است: ' + asset.sha256Asset + ' (هنگام دانلود اعتبارسنجی می‌شود)';
      else d.textContent = 'هش SHA-256 در Release منتشر نشده است؛ بسته بدون اعتبارسنجی هش دانلود می‌شود و این موضوع در پاسخ گزارش خواهد شد.';
    }
  }

  function checkGitHubRelease() {
    var btn = document.getElementById('bu-gh-check');
    if (btn) btn.disabled = true;
    ghMsg('در حال بررسی Release گیت‌هاب…', 'info');
    ghReleaseMsg('', 'info');
    fetch('/api/admin/updates/github/check', { method: 'POST', headers: headers(true), body: JSON.stringify({}) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        ghRelease = res.body || null;
        renderGitHubRelease();
        if (ghRelease && ghRelease.asset) {
          ghMsg('آخرین Release یافت شد', 'success');
        } else if (ghRelease) {
          ghMsg('Release یافت شد ولی فایل ZIP موجود نیست', 'danger');
        }
      })
      .catch(function (e) { ghMsg('خطا در بررسی GitHub: ' + (e.message || e), 'danger'); ghRelease = null; renderGitHubRelease(); })
      .finally(function () { if (btn) btn.disabled = false; });
  }

  function downloadGitHubRelease() {
    if (!ghRelease || !ghRelease.asset) { ghReleaseMsg('ابتدا Release را بررسی کنید', 'danger'); return; }
    var btn = document.getElementById('bu-gh-download');
    if (btn) btn.disabled = true;
    ghReleaseMsg('در حال دانلود و اعتبارسنجی…', 'info');
    fetch('/api/admin/updates/github/download', { method: 'POST', headers: headers(true), body: JSON.stringify({ asset: ghRelease.asset.name }) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        var b = res.body || {};
        ghDownloadedFile = b.filename || null;
        if (b.filename) setSelectedPackage(b.filename);
        loadPackages();
        loadStatus();
        var txt = 'دانلود انجام شد: ' + (b.savedPath || ('data/updates/' + (b.filename || ''))) +
          ' — نسخه ' + (b.version || '—') + ' — فایل ' + (b.filename || '');
        if (b.digestVerified) txt += ' — SHA-256 تأیید شد (' + (b.digestSource || 'release-digest') + ')';
        else if (b.digest) txt += ' — اعتبارسنجی SHA-256 ناموفق بود';
        else txt += ' — در Release هش SHA-256 منتشر نشده بود (بدون اعتبارسنجی هش)';
        ghReleaseMsg(txt, b.digestVerified || !b.digest ? 'success' : 'info');
        msg(txt, b.digestVerified || !b.digest ? 'success' : 'danger');
        if (b.filename) runValidation(b.filename);
      })
      .catch(function (e) { ghReleaseMsg('دانلود ناموفق: ' + (e.message || e), 'danger'); msg('دانلود ناموفق: ' + (e.message || e), 'danger'); })
      .finally(function () { if (btn) btn.disabled = false; });
  }

  /* ── Validation + explicit install confirmation ─────────────── */
  function currentPackage() {
    return selectedPackage || ghDownloadedFile || null;
  }

  function renderValidation(v, file) {
    var el = document.getElementById('bu-validation');
    if (!el) return;
    if (!v) { el.textContent = ''; return; }
    var lines = [];
    lines.push('فایل: ' + (file || '—'));
    lines.push('تعداد فایل‌ها: ' + (v.fileCount || 0) + ' — قابل نصب: ' + (v.installableFiles != null ? v.installableFiles : '—'));
    lines.push('حجم پس از باز شدن: ' + fmtBytes(v.totalUncompressed || 0));
    lines.push('نسخه داخل بسته: ' + (v.manifest && v.manifest.version ? v.manifest.version : '—'));
    lines.push('مسیرهای محافظت‌شده (حفظ می‌شوند): ' + (v.protectedCount || 0));
    var pe = v.protectedEntries || [];
    pe.slice(0, 12).forEach(function (p) { lines.push('  - ' + p); });
    if (pe.length > 12) lines.push('  … و ' + (pe.length - 12) + ' مورد دیگر');
    el.textContent = lines.join('\n');
  }

  function runValidation(file) {
    var el = document.getElementById('bu-validation-msg');
    file = file || currentPackage();
    if (!file) {
      if (el) { el.style.color = 'var(--text-muted)'; el.textContent = 'ابتدا یک بسته را انتخاب یا دانلود کنید'; }
      return Promise.resolve(null);
    }
    if (el) { el.style.color = 'var(--text-muted)'; el.textContent = 'در حال اعتبارسنجی…'; }
    return fetch('/api/admin/updates/validate', { method: 'POST', headers: headers(true), body: JSON.stringify({ file: file }) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        renderValidation(res.body.validation, res.body.file);
        if (el) { el.style.color = '#15803D'; el.textContent = 'بسته معتبر است' + (res.body.version ? (' — نسخه: ' + res.body.version) : ''); }
        return res.body;
      })
      .catch(function (e) {
        renderValidation(null);
        if (el) { el.style.color = '#B91C22'; el.textContent = 'بسته نامعتبر است: ' + (e.message || e); }
        msg('اعتبارسنجی ناموفق: ' + (e.message || e), 'danger');
        return null;
      });
  }

  function hideConfirmPanel() {
    var panel = document.getElementById('bu-confirm-panel');
    if (panel) panel.style.display = 'none';
  }

  /* The exact version + filename come from server-side validation of the
     staged package — never from a client-side guess. */
  function openInstallConfirm() {
    var pkg = currentPackage();
    if (!pkg) { msg('ابتدا یک بسته آپدیت را انتخاب یا از GitHub دانلود کنید', 'danger'); return; }
    var panel = document.getElementById('bu-confirm-panel');
    var chk = document.getElementById('bu-confirm-check');
    var applyBtn = document.getElementById('bu-confirm-apply');
    var cmsg = document.getElementById('bu-confirm-msg');
    if (cmsg) { cmsg.textContent = 'در حال اعتبارسنجی بسته…'; cmsg.style.color = 'var(--text-muted)'; }
    if (chk) chk.checked = false;
    if (applyBtn) applyBtn.disabled = true;
    if (panel) { panel.dataset.file = ''; panel.dataset.version = ''; panel.style.display = ''; }
    fetch('/api/admin/updates/validate', { method: 'POST', headers: headers(true), body: JSON.stringify({ file: pkg }) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        renderValidation(res.body.validation, res.body.file);
        var v = document.getElementById('bu-confirm-version');
        var f = document.getElementById('bu-confirm-file');
        var s = document.getElementById('bu-confirm-summary');
        if (v) v.value = res.body.version || '—';
        if (f) f.value = res.body.file || pkg;
        if (s) s.textContent = (res.body.version || '—') + ' با فایل ' + (res.body.file || pkg);
        if (panel) {
          panel.dataset.file = res.body.file || pkg;
          panel.dataset.version = res.body.version || '';
        }
        if (cmsg) {
          if (!res.body.version) {
            cmsg.style.color = '#B91C22';
            cmsg.textContent = 'این بسته فراداده نسخه ندارد؛ نصب با تأیید نسخه دقیق ممکن نیست.';
          } else {
            cmsg.style.color = '#15803D';
            cmsg.textContent = 'بسته معتبر است. برای فعال شدن دکمه نصب، تیک تأیید را بزنید.';
          }
        }
      })
      .catch(function (e) {
        if (cmsg) { cmsg.style.color = '#B91C22'; cmsg.textContent = 'نصب ممکن نیست — بسته نامعتبر است: ' + (e.message || e); }
        msg('اعتبارسنجی ناموفق: ' + (e.message || e), 'danger');
      });
  }

  function applyConfirmedUpdate() {
    var panel = document.getElementById('bu-confirm-panel');
    var chk = document.getElementById('bu-confirm-check');
    var applyBtn = document.getElementById('bu-confirm-apply');
    var cmsg = document.getElementById('bu-confirm-msg');
    if (!panel) return;
    var file = panel.dataset.file;
    var version = panel.dataset.version;
    if (!file || !version) {
      if (cmsg) { cmsg.style.color = '#B91C22'; cmsg.textContent = 'نسخه یا فایل نامعتبر است؛ دوباره بررسی کنید.'; }
      return;
    }
    if (!chk || !chk.checked) {
      if (cmsg) { cmsg.style.color = '#B91C22'; cmsg.textContent = 'برای نصب باید تأیید صریح را علامت بزنید.'; }
      return;
    }
    if (applyBtn) applyBtn.disabled = true;
    if (cmsg) { cmsg.style.color = 'var(--text-muted)'; cmsg.textContent = 'در حال ایجاد و صحت‌سنجی پشتیبان، سپس نصب…'; }
    fetch('/api/admin/backup/update/apply', {
      method: 'POST',
      headers: headers(true),
      body: JSON.stringify({ confirm: true, version: version, filename: file })
    })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.body && res.body.error) || 'failed');
        var b = res.body || {};
        var txt = 'نصب انجام شد: نسخه ' + (b.version || version) + ' — فایل ' + (b.package || file) +
          ' — فایل‌های تغییریافته: ' + (b.filesApplied != null ? b.filesApplied : '—') +
          ' — پشتیبان: ' + (b.backup && b.backup.filename ? b.backup.filename : '—') + ' (صحت‌سنجی شد)';
        if (cmsg) { cmsg.style.color = '#15803D'; cmsg.textContent = txt; }
        msg('به‌روزرسانی با موفقیت نصب شد', 'success');

        var notice = document.getElementById('bu-restart-notice');
        var rtext = document.getElementById('bu-restart-text');
        if (notice) notice.style.display = '';
        if (rtext) {
          var lines = [];
          lines.push('نسخه نصب‌شده: ' + (b.version || version) + ' — فایل: ' + (b.package || file));
          lines.push('پشتیبان ایجاد و صحت‌سنجی شد: ' + (b.backup && b.backup.filename ? b.backup.filename : '—'));
          if (b.preserved && b.preserved.length) {
            lines.push('مسیرهای حفظ‌شده (داده، آپلودها، اسرار، پشتیبان‌ها، لاگ‌ها): ' +
              b.preserved.slice(0, 8).join('، ') + (b.preserved.length > 8 ? ' …' : ''));
          }
          lines.push('سرور برای اعمال کد جدید ممکن است به راه‌اندازی مجدد نیاز داشته باشد. ' +
            'سرور به‌صورت خودکار ری‌استارت نشد — در صورت نیاز، ری‌استارت را دستی انجام دهید.');
          rtext.style.whiteSpace = 'pre-wrap';
          rtext.textContent = lines.join('\n');
        }
        hideConfirmPanel();
        loadStatus();
        loadPackages();
      })
      .catch(function (e) {
        if (cmsg) { cmsg.style.color = '#B91C22'; cmsg.textContent = 'نصب ناموفق: ' + (e.message || e); }
        msg('خطا در نصب: ' + (e.message || e), 'danger');
      })
      .finally(function () { if (applyBtn) applyBtn.disabled = !(chk && chk.checked); });
  }

  // bind
  var cBtn = document.getElementById('bu-create');
  if (cBtn) cBtn.addEventListener('click', createBackup);
  var dBtn = document.getElementById('bu-download');
  if (dBtn) dBtn.addEventListener('click', function () { downloadBackup(); });
  var uBtn = document.getElementById('bu-update-btn');
  if (uBtn) uBtn.addEventListener('click', openInstallConfirm);

  var vBtn = document.getElementById('bu-validate');
  if (vBtn) vBtn.addEventListener('click', function () { runValidation(); });

  var confirmChk = document.getElementById('bu-confirm-check');
  if (confirmChk) confirmChk.addEventListener('change', function () {
    var applyBtn = document.getElementById('bu-confirm-apply');
    if (applyBtn) applyBtn.disabled = !confirmChk.checked;
  });
  var confirmApplyBtn = document.getElementById('bu-confirm-apply');
  if (confirmApplyBtn) confirmApplyBtn.addEventListener('click', applyConfirmedUpdate);
  var confirmCancelBtn = document.getElementById('bu-confirm-cancel');
  if (confirmCancelBtn) confirmCancelBtn.addEventListener('click', hideConfirmPanel);

  var uploadBtn = document.getElementById('bu-upload-btn');
  if (uploadBtn) uploadBtn.addEventListener('click', uploadPackage);

  var ghSaveBtn = document.getElementById('bu-gh-save');
  if (ghSaveBtn) ghSaveBtn.addEventListener('click', saveGitHubConfig);
  var ghCheckBtn = document.getElementById('bu-gh-check');
  if (ghCheckBtn) ghCheckBtn.addEventListener('click', checkGitHubRelease);
  var ghDownloadBtn = document.getElementById('bu-gh-download');
  if (ghDownloadBtn) ghDownloadBtn.addEventListener('click', downloadGitHubRelease);

  document.addEventListener('change', function (e) {
    var r = e.target && e.target.name === 'bu-package' ? e.target : null;
    if (r && r.value) setSelectedPackage(r.value);
  });

  document.addEventListener('click', function (e) {
    var t = e.target && e.target.getAttribute && e.target.getAttribute('data-bu-download');
    if (t) downloadBackup(t);
    var d = e.target && e.target.getAttribute && e.target.getAttribute('data-bu-delete');
    if (d) deletePackage(d);
  });

  // Expose loader for admin.js showView hook (reliable first navigation).
  window.CamzyAdminBackup = { load: loadStatus };

  // initial if already on view
  if ((location.hash || '').replace(/^#\/?/, '') === 'backup-update') { loadStatus(); loadGitHubConfig(); }
})();
